const GetQualityAnalysis = ({ article }) => {
  const scores = {
    length: Math.min(100, Math.floor(article.content.length / 100)),
    images: article.images.length * 10,
    relevance: article.relatedArticles.length * 25,
    references: (article.content.match(/<a href/g) || []).length * 10,
    complexity: (article.content.match(/<p>/g) || []).length * 2,
  };

  const totalScore = scores.length + scores.images + scores.relevance + scores.references + scores.complexity;

  let badge = "";
  if (totalScore >= 350) badge = "🥇بلوط تنومند (کامل و مستحکم)";
  else if (totalScore >= 250) badge = "🥈 سرو (عالی) ";
  else if (totalScore >= 150) badge = "🥉  درخت سایه‌دار (سودمند)";
  else if (totalScore >= 80) badge = " نهال (رو به رشد) ";
  else badge = "بذر (نیاز به پرورش) ";

  // تحلیل طول محتوا
  let lengthComment = "";
  if (scores.length <= 20)
    lengthComment =
      "مقاله بسیار کوتاه است، در حدی که امکان بسط ایده‌ها و تعمیق معنایی در متن فراهم نمی‌شود و ساختار کلی اثر فاقد لایه‌بندی محتوایی است.";
  else if (scores.length <= 40)
    lengthComment =
      "طول مقاله نسبتاً کم است و باعث می‌شود متن دچار نوعی ایجاز افراطی باشد، درنتیجه ظرایف سبک‌شناختی و انسجام زبانی آسیب می‌بیند.";
  else if (scores.length <= 60)
    lengthComment =
      "مقاله از نظر طول در حد قابل قبولی قرار دارد و امکان ایجاد پیوستگی معنایی و بسط موضوع با حفظ شیوایی را فراهم می‌کند.";
  else if (scores.length <= 80)
    lengthComment =
      "طول مقاله مناسب و بالاست و این امکان را می‌دهد که نویسنده با پرداخت جزئی‌تر به مفاهیم، سبک خود را از طریق تکرار هنرمندانه و گسترش مفاهیم مدنظر خویش تثبیت کند.";
  else
    lengthComment =
      "مقاله بسیار بلند است، به نحوی که اگر مهارت کافی در کنترل ریتم و انسجام وجود نداشته باشد، ساختار سبکی دچار پراکندگی می‌کند و خواننده را ملول می‌کند.";

  // تحلیل تصاویر
  let imagesComment = "";
  if (scores.images <= 10)
    imagesComment =
      "عدم وجود تصاویر در مقاله باعث می‌شود وزن انتقال معنایی کاملاً بر دوش زبان بیفتد و فضای تصویری، که می‌تواند در القای ایده‌ها و مفاهیم نقش داشته باشد، حذف گردد.";
  else if (scores.images <= 30)
    imagesComment =
      "تعداد محدود تصاویر در متن، اگرچه می‌تواند موجب تمرکز بیشتر بر زبان شود، اما در روزگارِ کنونی که محتوای چندرسانه غالب است، کلام‌سالازی گاه تنوع ادراکی لازم برای غنی‌سازی روایت را کاهش می‌دهد.";
  else if (scores.images <= 50)
    imagesComment =
      "استفاده متعادل از تصاویر به متن کمک می‌کند تا چشمان مخاطب صرفاً بر حروف نلغزد و با ایجاد وقفه‌های دیداری، به تلطیف ریتم و فضای نوشته یاری رساند.";
  else if (scores.images <= 70)
    imagesComment =
      "این حجم از تصاویر موجود در متن امکان ایجاد سبکی بینارسانه‌ای را فراهم می‌آورند که در آن تعامل واژه و تصویر به خلق دلالت‌هایی چندلایه‌ منجر می‌شود.";
  else
    imagesComment =
      "تراکم بالای تصاویر ممکن است نوشتار را به حاشیه ببرد و کلام را خفیف کند و متنی پدید آورد که به جای تمرکز بر ظرافت‌های نوشتاری، بر انتقال مستقیم مفاهیم به صورت بصری تکیه دارد.";

  // تحلیل مقالات مرتبط
  let relevanceComment = "";
  if (scores.relevance <= 10)
    relevanceComment =
      "فقدان مقالات مرتبط در اثر باعث انزوای متنی می‌شود و متن را از امکان گفت‌وگو با دیگر متون مشابه محروم می‌کند.";
  else if (scores.relevance <= 30)
    relevanceComment =
      "حضور اندک مقالات مرتبط نشان‌دهنده نوعی خودبسندگی یا غفلت از پویایی بینامتنی است که می‌تواند سبک را به سمت تک‌صدایی سوق دهد.";
  else if (scores.relevance <= 50)
    relevanceComment =
      "استفاده متعادل از مقالات مرتبط کمک می‌کند تا اثر در بافت گسترده‌تر متون هم‌موضوع جای گیرد و سبک روایی آن غنای بیش‌تری یابد.";
  else if (scores.relevance <= 70)
    relevanceComment =
      "مقالات مرتبط فراوان به متن این امکان را می‌دهند که ضمن تبیین دیدگاه خود، با ایجاد دیالوگ‌های ضمنی با متون دیگر، فضایی چندآوایی پدید آورد.";
  else
    relevanceComment =
      "تکیه افراطی بر مقالات دیگر، اگر بدون بازآفرینی سبکی صورت گیرد، خطر ذوب شدن سبک فردی در میان ارجاعات بیرونی را در پی خواهد داشت.";

  // تحلیل منابع (لینک‌ها)
  let referencesComment = "";
  if (scores.references <= 10)
    referencesComment =
      "عدم ارجاع به منابع می‌تواند مقاله را بی‌پشتوانه نشان دهد و در عین حال آن را خودبسنده بنمایاند.";
  else if (scores.references <= 30)
    referencesComment =
      "میزان اندک منابع نشان می‌دهد که نویسنده گرچه به استقلال سبکی متمایل است، اما در تعامل با سنت‌های ادبی و متنی نیز به سر می‌برد.";
  else if (scores.references <= 50)
    referencesComment =
      "ارجاع‌های متعادل به منابع دیگر نه تنها به استحکام ساختاری متن کمک می‌کند بلکه موجب ایجاد روابط چندلایه معنایی می‌شود و مقاله را مستحکم نشان می‌دهد.";
  else if (scores.references <= 70)
    referencesComment =
      "تعدد ارجاعات می‌تواند به متن پویایی بیشتری ببخشد، اگرچه نیازمند مراقبت است تا انسجام و یکپارچگی متن و همچنین تشخص در تألیف به محاق نرود.";
  else
    referencesComment =
      "استفاده افراطی از منابع، متن را تبدیل به گلچینی از بیانات دیگران تبدیل می‌کند و چون گردوغبارهای پراکنده وزنی نمی‌گیرد.";

  // تحلیل پیچیدگی (براساس تعداد پاراگراف‌ها)
  let complexityComment = "";
  if (scores.complexity <= 10)
    complexityComment =
      "سادگی بیش از حد ساختار جملات و پاراگراف‌ها سبب می‌شود متن از لایه‌های سبکی تهی شود و خواننده را به تفکر ژرف دعوت نکند.";
  else if (scores.complexity <= 30)
    complexityComment =
      "ساختار نسبتاً ساده مقاله، اگرچه به روانی سبک کمک می‌کند، اما ممکن است از ایجاد فضای چندلایه ادبی و پیچیدگی معنایی جلوگیری کند.";
  else if (scores.complexity <= 50)
    complexityComment =
      "پیچیدگی متعادل در جملات و ساختار باعث می‌شود سبک متن هم دسترس‌پذیر و هم عمیق باشد، که این یکی از معیارهای سبکی موفق است.";
  else if (scores.complexity <= 70)
    complexityComment =
      "افزایش پیچیدگی در جملات می‌تواند به تولید سبکی پرمایه‌تر بینجامد که از مخاطب انتظار مشارکت فعال در رمزگشایی معانی را دارد.";
  else
    complexityComment =
      "پیچیدگی بیش از حد، اگر کنترل نشود، سبک نوشتاری را از شیوایی و وضوح دور کرده و خطر غامض شدن مفرط و فرار مخاطب را در پی دارد.";

  return (
    <div className="p-4 bg-gray-100 rounded-lg text-right" style={{ direction: "rtl" }}>
      <h3 className="font-bold mb-4">بررسی کیفیت محتوا:</h3>
      <p className="text-justify text-base/7">
        {lengthComment} در ادامه، {imagesComment}، در حالی که {relevanceComment}، و افزون بر آن{" "}
        {referencesComment}. همچنین {complexityComment} که تمامی این عوامل در کنار هم تصویری جامع از کیفیت
        سبکی و محتوایی این مقاله ارائه می‌کنند.
      </p>
      <div className="mt-4 font-bold text-xl text-center">نشان مقاله: {badge}</div>
    </div>
  );
};

export default GetQualityAnalysis;
